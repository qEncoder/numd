//
//  numd.h
//  numd
//
//  Created by Stephan on 21/08/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for numd.
FOUNDATION_EXPORT double numdVersionNumber;

//! Project version string for numd.
FOUNDATION_EXPORT const unsigned char numdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <numd/PublicHeader.h>

#import <numd/numd_functions.h>

